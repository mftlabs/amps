/*
 Licensed Materials - Property of IBM
 IBM Secure Proxy
 (C) Copyright IBM Corp. 2003, 2017 All Rights Reserved.
 US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*/

/**
 * Modification History
 * ========================= 
  * RTC#		   Date		     By	           Change
 * MFT-11536   2020-11-02    NM          Removed reading test cookie
 * SSP-4889    2020-11-26    NM          
 * SSP-4896    2020-11-30    NM
 */

var ssoMsgText;
var ssoMsgTitle;
var ssoMsgType;
var loginForm1;
var chgPwdForm
var initPageParm;		
var pwdPolicyExists;    //used by changepw.html
var timeout;            //used by passwdchanged.html
var fromPage;
var userId;
var tempElem;
var isRedirecting;
//===================================
//used by passwdchanged.html
var ssoMsgOnly = "false";  


<!-- change the loginURL value to http(s)://<host>:<port>/<login dir id e.g. Signon>/<your login page.html>  -->
var loginURL = "login.html";
var logoutURL = "logout.html";

<!-- change the changePwURL value to change password page. -->
var changePwURL = "changepw.html";

function gotoLogin() {
	if (isRedirecting)
		window.location=loginURL;
}

function logout() {
	window.location = logoutURL;
}

document.addEventListener('DOMContentLoaded', initialize, false);

function initialize(){
	//Used by passwordchanged.html
	tempElem = document.getElementById("passwordChangedBox");
	if (tempElem){
		tempElem.setAttribute("href", gotoLogin());
	}
	
	//set html "user" element value to the userid
	tempElem = document.getElementById("ssoUserId1");
	var userElem;
	if (tempElem){
		userId=tempElem.getAttribute("data-ssouserid1");
		userElem = document.getElementById('user');
		if (userElem){
			userElem.value = userId;
		}
		userElem = document.getElementById('userChgPwd');
		if (userElem){
			userElem.value = userId;
		}		
	}
	
	//set fromPage value (used by changepw.html)
	tempElem = document.getElementById("ssoFromPage");
	if (tempElem) {
		fromPage = tempElem.getAttribute("data-ssofrompage");
	}

	//set Password Policy strings (used by changepw.html)
	tempElem = document.getElementById("pwdPolicies0")
	if (tempElem) {
		pwdPolicyExists = tempElem.getAttribute("data-pwdpolicies0");
		if (pwdPolicyExists){
			addPwdPolicies();
		}
	}
	
	//setup initPage
	tempElem = document.getElementById("initPageParm");
	if (tempElem) initPageParm = tempElem.getAttribute("data-pageparam");

	tempElem = document.getElementById("timeout")
	if (tempElem) timeout = tempElem.getAttribute("data-timeout");

	
	//Assign  loginForm1 value as the POST url  (used by login.html - main login page)
	tempElem = document.getElementById("loginForm1")
	if (tempElem) loginForm1 = tempElem.getAttribute("data-loginform1");
    tempElem = document.getElementById("form1");
	if (tempElem) tempElem.setAttribute("action", loginForm1);
	
	//Assign  chgPwdForm value as the POST url (used by changepw.html)
	tempElem = document.getElementById("chgPwdForm")
	if (tempElem) chgPwdForm = tempElem.getAttribute("data-chgpwdform");
    tempElem = document.getElementById("form2");
	if (tempElem) tempElem.setAttribute("action", chgPwdForm);
	
	//set isRedirecting value, (used by passwordchanged.html)
	tempElem = document.getElementById("isRedirecting")
	if (tempElem) isRedirecting = tempElem.getAttribute("data-isredirecting");
	
	//set Href for 'Signout' link (used by welcome.html)
	tempElem = document.getElementById("signOutHref");
	if (tempElem) tempElem.setAttribute("href", logoutURL);
	
	//set Href for 'Change Password' link (used by welcome.html)
	tempElem = document.getElementById("chgPwdHref");
	if (tempElem) tempElem.setAttribute("href", changePwURL);
	
	//used by changepw.html to go back to welcome.html page
	tempElem = document.getElementById("cancelBtn");
	if (tempElem) {
		tempElem.addEventListener('click', function(){goBack(); return false;}, false); //return false;
	}
	
	//set up event listener for Forgot userid/password button in login.html
	tempElem = document.getElementById("popupMsgForgotHref");
	if (tempElem){
		//tempElem.getAttribute("href")= popupMessage('popupMessage', 'loginPanel');
		tempElem.addEventListener("click", function(){popupMessage('popupMessage', 'loginPanel');});
	}
	
	//set up event listener for Password Policy link in changepw.html
	tempElem = document.getElementById("popupMsgPwdPolicy");
	if (tempElem){
		tempElem.addEventListener("click", function(){popupMessage('popupMessage', 'loginPanel');});
	}
	
	//used in changepw.html for closing the Password Policy pop up
	tempElem = document.getElementById("popupMsgHref");
	if (tempElem){
		tempElem.addEventListener("click", function(){popupMessage('loginPanel', 'popupMessage');});
	}
	
	//get the values of ssoMsgText, ssoMsgTitle, ssoMsgType ...
	tempElem = document.getElementById("ssoMsgText");
	if (tempElem){
		ssoMsgText = tempElem.getAttribute("data-ssomsgtext");
	}
	tempElem = document.getElementById("ssoMsgTitle");
	if (tempElem){
		ssoMsgTitle = tempElem.getAttribute("data-ssomsgtitle");
	}
	tempElem = document.getElementById("ssoMsgType");
	if (tempElem){
		ssoMsgType = tempElem.getAttribute("data-ssomsgtype");
	}
	setUpMessage(ssoMsgText, ssoMsgTitle, ssoMsgType);

	var tempElem1 = document.getElementById("nCsrfToken")
	if (tempElem1){
		var csrfToken=tempElem1.getAttribute("data-csrftoken");
		document.getElementById('csrf_token').value = csrfToken;
	}
       

	//This event happens when he browser finishes loading the whole page
	document.body.addEventListener('onload', initPage(initPageParm, timeout)); 
}



function goBack() {
	if (fromPage && fromPage != "#{fromPage}") {
		window.location.assign(fromPage);  
	} else {
		window.location.assign(loginURL);
	}
}

function addPwdPolicies() {
	var pwdPolicyList = document.getElementById('pwdPolicyList');
	var policyStr = "";
	for (i = 0; i < 10; i++) {
		if (i == 0)  policyStr = document.getElementById("pwdPolicies0").getAttribute("data-pwdPolicies0");
		else if (i == 1) policyStr = document.getElementById("pwdPolicies1").getAttribute("data-pwdPolicies1");
		else if (i == 2) policyStr = document.getElementById("pwdPolicies2").getAttribute("data-pwdPolicies2");
		else if (i == 3) policyStr = document.getElementById("pwdPolicies3").getAttribute("data-pwdPolicies3");
		else if (i == 4) policyStr = document.getElementById("pwdPolicies4").getAttribute("data-pwdPolicies4");
		else if (i == 5) policyStr = document.getElementById("pwdPolicies5").getAttribute("data-pwdPolicies5");
		else if (i == 6) policyStr = document.getElementById("pwdPolicies6").getAttribute("data-pwdPolicies6");
		else if (i == 7) policyStr = document.getElementById("pwdPolicies7").getAttribute("data-pwdPolicies7");
		else if (i == 8) policyStr = document.getElementById("pwdPolicies8").getAttribute("data-pwdPolicies8");
		else if (i == 9) policyStr = document.getElementById("pwdPolicies9").getAttribute("data-pwdPolicies9");
			
		if (policyStr && policyStr.substring(0, 11) != "#{pwdPolicy") {
			var newPolicy = document.createElement('li');
			newPolicy.innerHTML = policyStr;
			pwdPolicyList.appendChild(newPolicy);
		} else {
			break;
		}
	}
}

function openCopyrightNotice()
{
	window.open("copyright.html","copyright","height=800,width=680,left=100,top=100,menubar=no,toolbar=no,resizable=yes,scrollbars=yes");
}	

function changePassword() {
	window.location = changePwURL;
}




// type can be info, warn, error
function setUpMessage(text, title, type) {

    var display = false;
    if (type && type != "#{ssoMsgType}") {
        var alertImg = document.getElementById("alertImg");
        alertImg.src = "resources/" + type + "_large.gif";
        display = true;
    }

    if (title && title != "#{ssoMsgTtle}") {
        var msgTitle = document.getElementById('alertTitle');
        msgTitle.innerHTML = title;
        display = true;
    }

    if (text && text != "#{ssoMsgText}") {
        var msg = document.getElementById('alertMessage');
        msg.innerHTML = text;
        display = true;
    }
	var msgDiv = document.getElementById('alertBox');
    if (msgDiv){
		if (display){
			msgDiv.style.visibility = 'visible';
		}else{
			msgDiv.style.visibility = 'hidden';
		}
	}
}

function popupMessage(showthis, hidethis) {
    var show = document.getElementById(showthis);
    var hide = document.getElementById(hidethis);

    show.style.visibility = "visible";
    hide.style.visibility = "hidden";
}

function initPage(focusElem, timeout) {

    if (top != self) {
        top.location = self.location;
        return;
    }

    var cookieEnabled = navigator.cookieEnabled; //MFT-11536
    var lcdiv = document.getElementById("logonContent");
    if (!cookieEnabled) {
        if (lcdiv)
            lcdiv.style.visibility = "hidden";

        ssoMsgText = "Please enable your cookie settings and try again.";
        ssoMsgType = "error";
    } else {
        if (lcdiv)
            lcdiv.style.visibility = "visible";
    }

    if (focusElem){
		var pwdElem;
		pwdElem = document.getElementById(focusElem);
        if (pwdElem) pwdElem.focus();
	}

	if (timeout){
		self.setTimeout('gotoLogin()', timeout);
	}
}

	
