validNewPassword = false;
validConfirmPassword = false;
var mySubmit = document.getElementById("logonBtn");

function hasClass(element, className) {
    return element.className && new RegExp("(^|\\s)" + className + "(\\s|$)").test(element.className);
}
function renderLoginButton() {
    var input1 = document.getElementById("newPwd");
    var input1Status = document.getElementById("newPwd_status");
    var input2 = document.getElementById("confirmPwd");
    var input2Status = document.getElementById("confirmPwd_status");
    var errMsg = document.getElementById("errmsg");
    if(hasClass(input1Status,"validpw")&&hasClass(input2Status,"validpw")&&input1.value==input2.value) {
        mySubmit.removeAttribute("disabled");
        errMsg.innerText="";
    } else if(hasClass(input1Status,"validpw")&&hasClass(input2Status,"validpw")&&input1.value!=input2.value) {
        errMsg.innerText="New Password and Verify Password do not match."
        mySubmit.setAttribute("disabled","disabled");
        input2Status.classList.remove("validpw");
        input2Status.classList.add("invalidpw");
    }else {
        mySubmit.setAttribute("disabled","disabled");
        errMsg.innerText="";
    }
}
function setupPasswordPolicyTest(myInputId,ctrlStyle) {

    //var myInput = document.getElementById("newpassword");
    var myInput = document.getElementById(myInputId);
    var myInputStatus = document.getElementById(myInputId+"_status");
    var letter = document.getElementById("letter");
    var capital = document.getElementById("capital");
    var number = document.getElementById("number");
    var length = document.getElementById("length");
    var special = document.getElementById("special");
    myInputStatus.classList.add("invalidpw");
    myInputStatus.setAttribute("style",ctrlStyle);
    // When the user clicks on the password field, show the message box
    myInput.onfocus = function() {
    document.getElementById("message").style.display = "block";
    }

    // When the user clicks outside of the password field, hide the message box
    myInput.onblur = function() {
    document.getElementById("message").style.display = "none";
    }

    // When the user starts to type something inside the password field
    myInput.onkeyup = function() {
    // Validate lowercase letters
    var hadLower = false;
    var hadUpper = false;
    var hadDigit = false;
    var hadLength = false;
    var hadSpecial = false;

    var lowerCaseLetters = /[a-z]/g;
    if(myInput.value.match(lowerCaseLetters)) { 
        letter.classList.remove("invalid");
        letter.classList.add("valid");
        hadLower = true;
    } else {
        letter.classList.remove("valid");
        letter.classList.add("invalid");
        hadLower = false;
    }

    // Validate capital letters
    var upperCaseLetters = /[A-Z]/g;
    if(myInput.value.match(upperCaseLetters)) { 
        capital.classList.remove("invalid");
        capital.classList.add("valid");
        hadUpper = true;
    } else {
        capital.classList.remove("valid");
        capital.classList.add("invalid");
        hadUpper = false;
    }

    // Validate numbers
    var numbers = /[0-9]/g;
    if(myInput.value.match(numbers)) { 
        number.classList.remove("invalid");
        number.classList.add("valid");
        hadDigit = true;
    } else {
        number.classList.remove("valid");
        number.classList.add("invalid");
        hadDigit = false;
    }
    if(myInput.value.length >= 8) {
        length.classList.remove("invalid");
        length.classList.add("valid");
        hadLength = true;
    } else {
        length.classList.remove("valid");
        length.classList.add("invalid");
        hadLength = false;
    }
    var specialchar = /[~\!@#\$%\^&\*\(\)\-_\+=\{\}\[\]\|\\;:<>,\.\/\?]/g
    if(myInput.value.match(specialchar)) { 
        special.classList.remove("invalid");
        special.classList.add("valid");
        hadSpecial = true;
    } else {
        special.classList.remove("valid");
        special.classList.add("invalid");
        hadSpecial = false;
    }
    // Validate length
        if( hadLower && hadUpper && hadDigit && hadLength && hadSpecial) {
            myInputStatus.classList.remove("invalidpw");
            myInputStatus.classList.add("validpw");
            console.log('Valid Input ',myInputId);
        } else {
            myInputStatus.classList.remove("validpw");
            myInputStatus.classList.add("invalidpw");
            console.log('Invalid Input ',myInputId);
        }
        renderLoginButton();
    }
}
function validatePasswordEntry() {
    //var mySubmit = document.getElementById("button_one");
    mySubmit.setAttribute("disabled","disabled");
    setupPasswordPolicyTest("newPwd","left: 385px;top: 117px;position: absolute;");
    setupPasswordPolicyTest("confirmPwd","left: 385px;top: 159px;position: absolute;");
}

validatePasswordEntry();

function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
        vars[key] = value;
    });
    return vars;
}

function getUrlParam(parameter, defaultvalue) {
    var urlparameter = defaultvalue;
    if (window.location.href.indexOf(parameter) > -1) {
        urlparameter = getUrlVars()[parameter];
    }
    return urlparameter;
}
var parameter = this.getUrlParam('c', 'Empty');
console.log('parameter value is', parameter);
if (parameter === '12') {
    setTimeout(function () {
        console.log("password reset success after 15 sec redirect to logout");
        window.location = '/Signon/logout.html'
    }, 4000);

}