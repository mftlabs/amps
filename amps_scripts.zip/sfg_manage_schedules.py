from sfg_base import sfg_base
from amps import Endpoint
import time
import traceback
import os
import requests
import json


class sfg_manage_schedules(sfg_base):
    def action(self):
        data = self.get_data()
        self.logger.info(data)
        self.schedules = json.loads(data)
        self.config = self.provider["values"]
        self.env = self.msg["path_params"]["env"]
        self.dc = self.msg["path_params"]["dc"]
        self.verbose = "verbose" in self.query_params
        self.entity = self.msg["path_params"]["entity"]
        action = self.msg["path_params"]["action"]
        self.logger.info('Got request for manage service {}'.format(self.schedules))

        if action not in ['start', 'stop', 'restart']:
            raise Exception(f'invalid action specified: {action}')
        self.setup()

        self.strategy = self.get_strategy()
        self.res = {"success": {}, "failed": {}}
        self.handle_action(action)


        return Endpoint.send_resp_data(self.res, 200)

    def handle_action(self, action):
        for sched in self.schedules:
            self.reset()
            self.initial = None
            self.logger.info(f'Doing {action} on {sched}')
            self.schedule = sched
            if self.entity != "schedules":
                sched = None
            if action == "start":
                self.strategy(self.start_scheduler, sched)
                actresp = self.get_act_resp()
                self.res[self.status][self.schedule] = {"start": actresp}
                
            if action == "stop":
                self.strategy(self.stop_scheduler, sched)
                actresp = self.get_act_resp()
                self.res[self.status][self.schedule] = {"stop": actresp}

            if action == "restart":
                self.cont = True
                self.strategy(self.stop_scheduler, sched)
                actresp = self.get_act_resp()
                self.res[self.status][self.schedule] = {"stop": actresp}
                time.sleep(5)
                if self.cont:
                    self.reset()
                    self.strategy(self.start_scheduler, sched)
                    actresp = self.get_act_resp()

                    self.res[self.status][self.schedule] = {"start": actresp}

    def get_act_resp(self):
        actresp =  {"resp": self.resp}
        if self.verbose:
            actresp["initial"] = self.initial
        return actresp

    def start_scheduler(self, retry):
        self.manage_scheduler(retry, True)

    def stop_scheduler(self, retry):
        self.manage_scheduler(retry, False)


    def get_schedule_info(self, index):
        url = self.scheduler_urls[index]+self.get_uri
        resp = requests.get(url.format(self.scheduler_name),
                            auth=self.auth, headers=self.headers, verify=False)
        print(resp.status_code)
        if resp.status_code == 200:
            return json.loads(resp.text)
        return None

    def is_schedule_active(self, index):
        url = self.scheduler_urls[index]+self.get_uri
        resp = requests.get(url.format(self.scheduler_name),
                            auth=self.auth, headers=self.headers, verify=False)
        if resp.status_code == 200:
            result = json.loads(resp.text)
            if len(result) > 0:
                details = result
                return details['scheduleStatusEnabled']['code'] == True
        return None

    def manage_scheduler(self, retry, enable):
        self.logger.info(f'Managing with {enable}')
        self.logger.info(f'url {self.url}')
        if self.entity == "schedules":
            resp = self.response = requests.get(
                self.url, auth=self.auth, headers=self.headers, verify=False)
        else:
            qp = {"_range": "0-999", "serviceName": self.schedule}
            resp = self.response = requests.get(
                self.url, auth=self.auth, params=qp, headers=self.headers, verify=False)
        self.logger.info('Retrieving {} returned status code {}'.format(
            self.schedule, resp.status_code))
        self.logger.info(f'Status code {resp.status_code}')
        if resp.status_code == 200:
            self.logger.info(f'Status code {resp.status_code}')
            self.logger.info(resp.text)
            self.initial = resp.json()
            result = json.loads(resp.text)
            self.logger.info(resp.text)
            self.logger.info(
                'Received payload from server: {}'.format(resp.text))
            if len(result) > 0:
                self.logger.info(f'url {self.url}')
                if self.entity == "schedules":
                    details = {}
                    details['scheduleStatusEnabled'] = enable
                    resp2 = requests.patch(
                        self.url, auth=self.auth, headers=self.headers, data=json.dumps(details), verify=False)
                else:
                    details = result[0]
                    details['Enable'] = enable
                    del details['$ref']
                    del details['href']
                    del details['createDate']
                    url = "/".join(piece.strip("/") for piece in [self.url, details["_id"]])
                    resp2 = requests.put(url, auth=self.auth, headers=self.headers, data=json.dumps(details), verify=False)
                self.logger.info('Update status returned status code {}'.format(resp2.status_code))
                self.logger.info('Response received <br/>{}'.format(resp2.text))
                if resp2.status_code == 200:
                    self.status = "success"
                    self.resp = resp2.json()
                else:
                    if retry:
                        try:
                            retry()
                        except ValueError as e:
                            self.cont = False
                            self.status = "failed"
                            self.resp = resp2.json()
                        
        else:
            if retry:
                try:
                    retry()
                except ValueError as e:
                    self.cont = False
                    self.status = "failed"
                    self.resp = resp.json()
