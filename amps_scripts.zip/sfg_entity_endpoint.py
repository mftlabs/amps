from amps import Endpoint


class sfg_entity_endpoint(Endpoint):
    def action(self):
        self.request = self.msg["path_params"]["request"]
        self.entity = self.request[0]
        self.method = self.msg["method"]
        return Endpoint.send_resp_data("Async Operation", 200)
