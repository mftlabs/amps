from amps import Endpoint
from requests.auth import HTTPBasicAuth


class sfg_base(Endpoint):
    def get_strategy(self):
        strategies = {"CDSPOE": self.every_node}
        strategy = strategies.get(self.entity)
        if strategy:
            return strategy
        else:
            return self.once_per_dc

    def setup(self):
        dc = self.dc
        user = self.config["sfg_api_user"]
        pwd = self.config[f'{self.env}_sfg_api_pwd']
        self.auth = HTTPBasicAuth(user, pwd)
        self.nodes = self.config.get(f'{self.env}_{dc}_nodes_list')

        if self.nodes:
            self.nodes = self.nodes.split(",")
        else:
            self.nodes = []

        self.logger.info('Nodes list {}'.format(str(self.nodes)))
        self.currnode = -1
        self.scheme = self.config["scheme"]
        self.port = self.config["port"]
        self.headers = {'Content-Type': 'application/json', "Accept": 'application/json'}

    def reset(self):
        self.currnode = -1

    def get_next(self):
        self.currnode += 1
        if self.currnode < len(self.nodes):
            base_url = f'{self.scheme}://{self.nodes[self.currnode]}:{self.port}'
            self.logger.info('Base Url {}'.format(base_url))
            pieces = [base_url, self.config["sfg_api_uri"], self.entity]
            url = "/".join(piece.strip("/") for piece in pieces) + "/"
            self.logger.info(url)
            return url
        else:
            return False

    def once_per_dc(self, func, uri=None):
        def callback(): return self.once_per_dc(func, uri)
        self.url = self.get_next()
        self.logger.info(self.url)
        if self.url:
            try:
                if uri:
                    self.url = "/".join(piece.strip("/") for piece in [self.url, uri]) + "/"
                func(callback)
            except Exception as e:
                self.logger.error(str(e))
                self.response = str(e)
                callback()

        else:
            raise ValueError("Failed on all nodes")

    def every_node(self):
        pass
