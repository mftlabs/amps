from amps import Action
import requests
from requests.auth import HTTPBasicAuth

class sfg_entity(Action):
 def action(self):
    self.request = self.msg["path_params"]["request"]
    self.env = self.msg["path_params"]["env"]
    self.qp = self.msg["query_params"]
    self.logger.info('Request contains {}'.format(self.request))
    self.entity = self.request[0]
    self.name = None
    if len(self.request) > 1:
        self.name = self.request[1]
    self.method = self.msg["method"]
    if self.method == "POST" or self.method == "PUT":
        self.body = open(self.msg["fpath"]).read()
    self.config = self.provider["values"]
    self.setup()
    self.status = "completed"
    operations = {"POST": {"func": self.do_post}, "PUT": {"func": self.do_put, "uri": self.name}, "DELETE": {"func": self.do_delete, "uri": self.name}}
    op = operations[self.method]
    self.get_strategy()(op["func"], op.get("uri"))
 
    return Action.send_async(self.status, self.extra["dc"], self.res)
 

 def get_strategy(self):
    strategies = {"CDSPOE": self.every_node}
    strategy = strategies.get(self.entity)
    if strategy:
        return strategy
    else:
        return self.once_per_dc


 def setup(self):
    dc = self.extra.get("dc")
    user = self.config["sfg_api_user"]
    pwd = self.config[f'{self.env}_sfg_api_pwd']
    self.auth = HTTPBasicAuth(user, pwd)
    self.nodes = self.config.get(f'{self.env}_{dc}_nodes_list')

    if self.nodes:
        self.nodes = self.nodes.split(",")
    else:
        self.nodes = []

    self.logger.info('Nodes list {}'.format(str(self.nodes)))
    self.currnode = -1
    self.scheme = self.config["scheme"]
    self.port = self.config["port"]

 def get_next(self):
    self.currnode += 1
    if self.currnode < len(self.nodes):
        base_url = f'{self.scheme}://{self.nodes[self.currnode]}:{self.port}'
        self.logger.info('Base Url {}'.format(base_url))
        pieces = [base_url, self.config["sfg_api_uri"], self.entity]
        url = "/".join(piece.strip("/") for piece in pieces) + "/"
        self.logger.info(url)
        return url
    else:
        return False

 def once_per_dc(self, func, uri=None):
    callback = lambda: self.once_per_dc(func, uri)
    self.url = self.get_next()
    self.logger.info(self.url)
    if self.url:
        try:
            if uri:
                self.url = "/".join([self.url, uri]) + "/"
            func(callback)
        except Exception as e:
            self.logger.error(str(e))
            self.response = str(e)
            callback()
    
    else:
        raise ValueError("Failed on all nodes")
 def every_node(self):
    pass
 def do_post(self, retry = None):
    headers = {'Content-Type': 'application/json'}
    self.response = requests.post(self.url, params=self.qp, auth=self.auth, headers=headers, data=self.body, verify=False)
    self.logger.info(self.response.text)
    if self.response.status_code != 201:
        if 'already exists' not in self.response.text:
            if retry:
                retry()
    self.res = self.response.json()
 
 # do post
 def do_put(self, retry = None):
    headers = {'Content-Type': 'application/json'}
    self.response = requests.put(self.url, params=self.qp, auth=self.auth, headers=headers, data=self.body, verify=False)
    if self.response.status_code != 200:
        if retry:
            retry()
    self.res = self.response.json()
 # do put

 def do_delete(self, retry):
    headers = {'Content-Type': 'application/json'}
    self.response = requests.delete(self.url, params=self.qp, auth=self.auth, headers=headers, verify=False)
    if self.response.status_code != 200 and self.response.status_code != 404:
        if retry:
            retry()
    self.res = self.response.json()
 # delete