from amps import Endpoint
import requests
from requests.auth import HTTPBasicAuth
import os


class sfg_get(Endpoint):
    def action(self):
        self.request = self.msg["path_params"]["request"]
        self.env = self.path_params["env"]

        self.entity = self.request[0]
        self.name = None
        if len(self.request) > 1:
            self.name = self.request[1]
        #self.qparms = self.msg["query_params"]
        self.config = self.provider["values"]
        self.setup()
        self.once_per_dc(self.do_get, self.name)
        return self.res


    
    def setup(self):
        self.auth = HTTPBasicAuth(self.config["sfg_api_user"], self.config[f'{self.env}_sfg_api_pwd'])
        self.dcs = self.extra["dc_list"].split(",")
        self.currnode = -1
        self.currdc = 0
        self.scheme = self.config["scheme"]
        self.port = self.config["port"]

    def get_next(self):
        self.nodes = self.config.get(f'{self.env}_{self.dcs[self.currdc]}_nodes_list')

        if self.nodes:
            self.nodes = self.nodes.split(",")
        else:
            self.nodes = []


        self.currnode += 1
        if self.currnode < len(self.nodes):
            base_url = f'{self.scheme}://{self.nodes[self.currnode]}:{self.port}'
            self.logger.info(base_url)
            pieces = [base_url, self.config["sfg_api_uri"], self.entity]
            url = "/".join(piece.strip("/") for piece in pieces) + "/"
            self.logger.info(url)
            return url
        else:
            if self.currdc < len(self.dcs) - 1:
                self.currdc += 1
                self.get_next()
            else:
                return False

    def once_per_dc(self, func, uri=None):
        callback = lambda: self.once_per_dc(func, uri)
        self.url = self.get_next()
        if self.url:
            try:
                if uri:
                    self.url = "/".join([self.url, uri])
                func(callback)
            except Exception as e:
                self.logger.error(str(e))
                self.response = str(e)
                callback()
        
        else:
            self.status = "retry"
            self.res = Endpoint.send_resp_data("Failed on all nodes", 400)


    def do_get(self, retry):
        headers = {'Accept': "application/json"}
        if self.query_params.get("_range"):
            params = self.query_params
        else:
            params = {**self.query_params, **{"_range": "0-25"}}
        response = requests.get(
        self.url, headers=headers, auth=self.auth, params=params, verify=False)
        if response.status_code != 200:
            self.logger.info(response.status_code)

            if response.status_code == 404:
                self.res = Endpoint.send_resp_data(response.json(), 404)
            else:
                if retry:
                    retry()
        else:
            resp = response.json()
            self.res = Endpoint.send_resp_data(resp, 200)